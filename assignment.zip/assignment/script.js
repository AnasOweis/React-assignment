function calculateSumAndAvarage(numbers){

    if (numbers.length==0){
        return{
    sum:0,
    avarage:0
    };
}
const sum =numbers.reduce((accumulator, currentvalue)=> accumulator + currentvalue,0);

const avarage = sum/numbers.length;

return {
    sum,
    avarage
};
}
const numbers=[5,10,15,20,25,30];
const result = calculateSumAndAvarage(numbers);
console.log(`Our Sum is  ${result.sum}`)
console.log(`Our avarage is ${result.avarage}`)
