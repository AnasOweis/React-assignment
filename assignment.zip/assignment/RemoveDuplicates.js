function removeDuplicates(strings){
    const uniqset = new Set(strings);
    const uniqarray= [...uniqset];
    return uniqarray
}

const strings = ["rasheed","sara","Layan","Anas","Anas"];
const uniqstrings = removeDuplicates(strings);
console.log(uniqstrings)