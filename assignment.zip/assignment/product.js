function calculateTotalPrice(products) {
    return products.reduce(function (total, product) { return total + product.price; }, 0);
}
var products = [
    { name: "Laptop", price: 1200 },
    { name: "Phone", price: 800 },
    { name: "Headphones", price: 150 }
];
var totalPrice = calculateTotalPrice(products);
console.log("Total Price: $".concat(totalPrice));
