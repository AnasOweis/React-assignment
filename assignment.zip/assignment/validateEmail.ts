function isValidEmail(email: string): boolean {  
    
      const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;    
      return emailRegex.test(email); } 
      const testEmails = [   
          "test@example.com",   
          "invalid-email",      "user@domain",       ];
          
          testEmails.forEach((email) => { console.log(`${email} is valid: ${isValidEmail(email)}`); });