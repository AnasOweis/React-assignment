function isValidEmail(email) {
    var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
}
var testEmails = [
    "test@example.com",
    "invalid-email", 
    "user@domain",
];
testEmails.forEach(function (email) { console.log("".concat(email, " is valid: ").concat(isValidEmail(email))); });
